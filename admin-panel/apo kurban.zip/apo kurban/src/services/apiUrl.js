export const userUrl = "http://localhost:4000/user";
export const roleUrl = "http://localhost:4000/role";
export const permissionUrl = "http://localhost:4000/permission";
export const taskUrl = "http://localhost:4000/task";
export const flowUrl = "http://localhost:4000/flow";
export const settingsUrl = "http://localhost:4001/settings";
